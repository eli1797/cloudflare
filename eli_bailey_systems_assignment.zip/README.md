# cli_http: Go Gets that URL

## Usage

From directory
`go run cli_http.go --url=https://example.com --profile=1`

or 

Build
`go build cli_http.go`
Run
`./cli_http --url=https://example.com --profile=1`

## Flags

--url=The url to make a GET request to
--help=true to show usage tips, default false
--profile=How many times to make the request, default 1

## Output

Outputs the reponse as a string and stats on performance

Example Command and Output:
```
C:\Users\Elijah Bailey\cloudflare>go run cli_http.go --url=https://royal-limit-f596.elibailey.workers.dev/links --profile=1
2020/10/19 16:25:54 [{"name":"Personal_Site","url":"https://elibailey.org/"},{"name":"LinkedIn","url":"https://www.linkedin.com/in/elijahbailey/"},{"name":"Github","url":"https://github.com/eli1797"}]

URL: https://royal-limit-f596.elibailey.workers.dev/links
1 Request(s)
Fastest Time (ms): 112
Slowest Time (ms): 112
Mean Time (ms): 112
Median Time (ms): 112
100 percent successful
Largest Response (bytes): 180
Smallest Response (bytes): 127
```
